from app import addition

def test_addition():
    assert addition(2, 3) == 5
